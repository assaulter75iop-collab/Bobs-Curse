package com.bobscurse;

import com.bobscurse.registry.ModEntities;
import com.bobscurse.registry.ModItems;
import com.bobscurse.story.StoryEvents;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import software.bernie.geckolib.GeckoLib;

@Mod(BobsCurse.MOD_ID)
public class BobsCurse {
    public static final String MOD_ID = "bobs_curse";
    public BobsCurse() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        GeckoLib.initialize();
        ModEntities.ENTITY_TYPES.register(bus);
        ModItems.ITEMS.register(bus);
        bus.addListener(ModEntities::registerAttributes);
        bus.addListener(ModItems::addCreative);
        MinecraftForge.EVENT_BUS.register(new StoryEvents());
    }
}
