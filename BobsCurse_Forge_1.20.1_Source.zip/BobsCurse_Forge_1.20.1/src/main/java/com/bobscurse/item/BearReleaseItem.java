package com.bobscurse.item;

import com.bobscurse.entity.BearEntity;
import com.bobscurse.registry.ModEntities;
import com.bobscurse.story.StoryEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class BearReleaseItem extends Item {
    private final boolean poppy;
    public BearReleaseItem(boolean poppy, Properties properties) { super(properties); this.poppy = poppy; }

    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);
        BlockPos pos = player.blockPosition().relative(player.getDirection());
        if (!level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()) pos = player.blockPosition().above();
        if (poppy) {
            BearEntity poppyEntity = ModEntities.POPPY.get().create(level);
            if (poppyEntity == null) return InteractionResultHolder.fail(stack);
            poppyEntity.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, player.getYRot(), 0);
            poppyEntity.tame(player);
            level.addFreshEntity(poppyEntity);
            StoryEvents.heal(player);
            player.displayClientMessage(Component.literal("Poppy has returned. The curse is broken."), true);
            level.sendParticles(ParticleTypes.HEART, poppyEntity.getX(), poppyEntity.getY() + 0.8, poppyEntity.getZ(), 12, 0.4, 0.5, 0.4, 0.03);
        } else {
            BearEntity bob = ModEntities.BOB.get().create(level);
            if (bob == null) return InteractionResultHolder.fail(stack);
            bob.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, player.getYRot(), 0);
            bob.tame(player);
            level.addFreshEntity(bob);
            bob.playSound(SoundEvents.POLAR_BEAR_AMBIENT_BABY, 0.8F, 1.25F);
            player.displayClientMessage(Component.literal("Bob: Hello, friend! I'll follow you."), true);
            level.sendParticles(ParticleTypes.HEART, bob.getX(), bob.getY() + 0.7, bob.getZ(), 5, 0.3, 0.3, 0.3, 0.02);
        }
        if (!player.getAbilities().instabuild) stack.shrink(1);
        return InteractionResultHolder.consume(stack);
    }
}
