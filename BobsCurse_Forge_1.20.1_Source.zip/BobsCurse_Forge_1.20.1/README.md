# Bob's Curse — Forge 1.20.1

This is a real Forge source project ported from the supplied 4.55 MB Bob's Curse archive. It retains the original Blockbench `.bbmodel` files, GeckoLib `.geo.json` models, animation JSON, entity textures, item textures, loot tables, and recipe data.

## Target
- Minecraft Java Edition 1.20.1
- Minecraft Forge 47.4.29
- Java 17
- GeckoLib Forge 1.20.1, version 4.7.3

## Build
1. Install a JDK 17.
2. Install Gradle 8.1+ (or open the folder in IntelliJ IDEA with the Gradle plugin).
3. In this folder run `gradle build`.
4. The reobfuscated mod JAR will be in `build/libs/`.
5. Put that JAR and the GeckoLib Forge 1.20.1 JAR in the instance's `mods` folder.

ForgeGradle and GeckoLib dependencies are downloaded by Gradle on the first build, so the first build needs internet access.

## Implemented in this port
- Forge mod entrypoint and deferred registration
- Four registered GeckoLib entities: Bob, Poppy, Fallen Poppy, and Killer Bear
- Original custom entity geometry, texture, and animation assets wired to GeckoLib renderers
- Pocket Bob item spawns tameable Bob
- Revived Poppy item spawns Poppy and clears the player's curse
- Spawn eggs and creative-tab entries
- Starter items on first login
- Persistent 48,000-tick trauma progression, night-time Bob awakening, and rescue/healing state
- Revived Poppy crafting recipe

## Important port notes
The original archive's Java sources target a much newer Minecraft/Fabric API and Java 25; those classes cannot be copied into a 1.20.1 Forge project. The gameplay systems have therefore been reimplemented against Forge 1.20.1 APIs while preserving the supplied art assets. This is a source project, not a precompiled or runtime-tested JAR. Compile it with the toolchain above before installing it. GeckoLib is a required dependency and must be installed separately.
