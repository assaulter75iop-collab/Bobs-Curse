package com.bobscurse.entity;

import com.bobscurse.registry.ModEntities;
import com.bobscurse.story.StoryEvents;
import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.level.Level;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

public class BearEntity extends TamableAnimal implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private boolean redeemed;

    public BearEntity(EntityType<? extends TamableAnimal> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        if (isBody()) setNoAi(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return net.minecraft.world.entity.Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 30).add(Attributes.MOVEMENT_SPEED, 0.28).add(Attributes.ATTACK_DAMAGE, 4).add(Attributes.FOLLOW_RANGE, 48);
    }

    private boolean isBob() { return getType() == ModEntities.BOB.get(); }
    private boolean isPoppy() { return getType() == ModEntities.POPPY.get(); }
    private boolean isBody() { return getType() == ModEntities.FALLEN_POPPY.get(); }
    private boolean isKiller() { return getType() == ModEntities.KILLER_BEAR.get(); }
    public boolean isRedeemed() { return redeemed; }
    public void redeem() { redeemed = true; }

    public String appearance() {
        if (isBob()) return getOwner() instanceof Player owner && owner.getPersistentData().getInt("bobs_curse_trauma") >= 100 ? "bob_angry" : "bob";
        if (isPoppy()) return "poppy";
        if (isBody()) return "fallen_poppy";
        return "killer_bear";
    }

    @Override protected void registerGoals() {
        if (isBody()) return;
        goalSelector.addGoal(0, new FloatGoal(this));
        if (isKiller()) {
            goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2, true));
            targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
        } else {
            goalSelector.addGoal(1, new FollowOwnerGoal(this, 1.05, 8.0F, 2.0F, false));
            goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.9));
            goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0F));
            goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        }
    }

    @Override public void tick() {
        super.tick();
        if (!level().isClientSide && isBob() && !redeemed && tickCount % 20 == 0) {
            List<BearEntity> friends = level().getEntitiesOfClass(BearEntity.class, getBoundingBox().inflate(6), e -> e.isPoppy() && e.isAlive());
            if (!friends.isEmpty()) {
                redeemed = true;
                if (getOwner() instanceof Player player) StoryEvents.heal(player);
            }
        }
    }

    @Override public boolean isFood(net.minecraft.world.item.ItemStack stack) { return false; }
    @Override public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob mate) { return null; }
    @Override protected SoundEvent getAmbientSound() { return isKiller() ? SoundEvents.POLAR_BEAR_WARNING : SoundEvents.POLAR_BEAR_AMBIENT_BABY; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.POLAR_BEAR_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.POLAR_BEAR_DEATH; }

    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 5, this::animate));
    }
    private PlayState animate(AnimationState<BearEntity> state) {
        String anim = appearance();
        String animation = anim.equals("killer_bear") ? "animation.killer_bear.grizzly_walk" : anim.equals("poppy") ? "animation.poppy.bear_cub_walk" : anim.equals("bob_angry") ? "animation.bob_angry.bear_run" : "animation.bob.bear_cub_walk";
        state.getController().setAnimation(RawAnimation.begin().thenLoop(animation));
        return PlayState.CONTINUE;
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
