package com.bobscurse.story;

import com.bobscurse.entity.BearEntity;
import com.bobscurse.registry.ModItems;
import com.bobscurse.registry.ModEntities;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class StoryEvents {
    private static final String START = "bobs_curse_start";
    private static final String TRAUMA = "bobs_curse_trauma";
    private static final String HEALED = "bobs_curse_healed";
    private static final String KIT = "bobs_curse_kit";

    @SubscribeEvent public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!player.getPersistentData().getBoolean(KIT)) {
            player.getInventory().add(new ItemStack(ModItems.POCKET_BOB.get()));
            player.getInventory().add(new ItemStack(ModItems.POPPY_BODY.get()));
            player.getPersistentData().putBoolean(KIT, true);
            player.getPersistentData().putLong(START, player.level().getGameTime());
            player.displayClientMessage(Component.literal("Bob's Curse has begun. Find a way to bring Poppy back."), false);
        }
    }

    @SubscribeEvent public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide || !(event.player instanceof ServerPlayer player)) return;
        if (player.getPersistentData().getBoolean(HEALED)) return;
        if (!player.getPersistentData().contains(START)) player.getPersistentData().putLong(START, player.level().getGameTime());
        long elapsed = Math.max(0, player.level().getGameTime() - player.getPersistentData().getLong(START));
        int trauma = (int)Math.min(100, elapsed * 100L / 48000L);
        player.getPersistentData().putInt(TRAUMA, trauma);
        if (player.tickCount % 100 == 0 && trauma > 0) {
            player.displayClientMessage(Component.literal("Bob's Trauma: " + trauma + "%"), true);
        }
        long dayTime = player.level().getDayTime() % 24000L;
        if (trauma >= 100 && dayTime >= 13000 && dayTime <= 23000 && player.tickCount % 100 == 0) {
            for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
                ItemStack stack = player.getInventory().getItem(i);
                if (stack.is(ModItems.POCKET_BOB.get())) {
                    BearEntity bob = ModEntities.BOB.get().create(player.level());
                    if (bob != null) {
                        bob.moveTo(player.getX() + 1.5, player.getY(), player.getZ(), player.getYRot(), 0);
                        bob.tame(player);
                        player.level().addFreshEntity(bob);
                        stack.shrink(1);
                        player.displayClientMessage(Component.literal("The darkness has awakened Bob..."), false);
                    }
                    break;
                }
            }
        }
    }

    public static void heal(Player player) {
        player.getPersistentData().putBoolean(HEALED, true);
        player.getPersistentData().putInt(TRAUMA, 0);
        player.displayClientMessage(Component.literal("Poppy is safe. Bob's curse has been lifted!"), false);
    }
}
