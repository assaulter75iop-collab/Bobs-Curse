package com.bobscurse.registry;

import com.bobscurse.BobsCurse;
import com.bobscurse.entity.BearEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, BobsCurse.MOD_ID);
    public static final RegistryObject<EntityType<BearEntity>> BOB = ENTITY_TYPES.register("bob", () -> EntityType.Builder.of(BearEntity::new, MobCategory.CREATURE).sized(0.95f, 0.7f).clientTrackingRange(10).build("bobs_curse:bob"));
    public static final RegistryObject<EntityType<BearEntity>> POPPY = ENTITY_TYPES.register("poppy", () -> EntityType.Builder.of(BearEntity::new, MobCategory.CREATURE).sized(0.95f, 0.75f).clientTrackingRange(10).build("bobs_curse:poppy"));
    public static final RegistryObject<EntityType<BearEntity>> FALLEN_POPPY = ENTITY_TYPES.register("fallen_poppy", () -> EntityType.Builder.of(BearEntity::new, MobCategory.MISC).sized(0.95f, 0.35f).clientTrackingRange(10).build("bobs_curse:fallen_poppy"));
    public static final RegistryObject<EntityType<BearEntity>> KILLER_BEAR = ENTITY_TYPES.register("killer_bear", () -> EntityType.Builder.of(BearEntity::new, MobCategory.MONSTER).sized(1.4f, 0.85f).clientTrackingRange(12).build("bobs_curse:killer_bear"));

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(BOB.get(), attributes(30, 0.28, 4).build());
        event.put(POPPY.get(), attributes(80, 0.36, 9).build());
        event.put(FALLEN_POPPY.get(), attributes(1, 0, 0).build());
        event.put(KILLER_BEAR.get(), attributes(200, 0.30, 10).build());
    }
    private static AttributeSupplier.Builder attributes(double hp, double speed, double damage) {
        return BearEntity.createAttributes().add(Attributes.MAX_HEALTH, hp).add(Attributes.MOVEMENT_SPEED, speed).add(Attributes.ATTACK_DAMAGE, damage).add(Attributes.FOLLOW_RANGE, 48.0);
    }
}
