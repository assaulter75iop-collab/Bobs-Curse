package com.bobscurse.registry;

import com.bobscurse.BobsCurse;
import com.bobscurse.item.BearReleaseItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.common.ForgeSpawnEggItem;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, BobsCurse.MOD_ID);
    public static final RegistryObject<Item> POCKET_BOB = ITEMS.register("pocket_bob", () -> new BearReleaseItem(false, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> POPPY_BODY = ITEMS.register("poppy_body", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> REVIVED_POPPY = ITEMS.register("revived_poppy", () -> new BearReleaseItem(true, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> FOREST_HEART = ITEMS.register("forest_heart", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> BOB_SPAWN_EGG = ITEMS.register("bob_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.BOB, 0x5C3928, 0xD8B68A, new Item.Properties()));
    public static final RegistryObject<Item> POPPY_SPAWN_EGG = ITEMS.register("poppy_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.POPPY, 0x7D4B35, 0xE9C49C, new Item.Properties()));
    public static final RegistryObject<Item> FALLEN_POPPY_SPAWN_EGG = ITEMS.register("fallen_poppy_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.FALLEN_POPPY, 0x514035, 0xA99A83, new Item.Properties()));
    public static final RegistryObject<Item> KILLER_BEAR_SPAWN_EGG = ITEMS.register("killer_bear_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.KILLER_BEAR, 0x201A18, 0x9B1E1E, new Item.Properties()));

    public static void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) { event.accept(POCKET_BOB); event.accept(REVIVED_POPPY); }
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) { event.accept(POPPY_BODY); event.accept(FOREST_HEART); }
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) { event.accept(BOB_SPAWN_EGG); event.accept(POPPY_SPAWN_EGG); event.accept(FALLEN_POPPY_SPAWN_EGG); event.accept(KILLER_BEAR_SPAWN_EGG); }
    }
}
