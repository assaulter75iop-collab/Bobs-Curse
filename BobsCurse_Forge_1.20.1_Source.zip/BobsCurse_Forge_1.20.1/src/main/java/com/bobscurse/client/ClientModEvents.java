package com.bobscurse.client;

import com.bobscurse.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.client.event.EntityRenderersEvent;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import com.bobscurse.entity.BearEntity;
import software.bernie.geckolib.model.GeoModel;
import net.minecraft.resources.ResourceLocation;

@Mod.EventBusSubscriber(modid = "bobs_curse", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.BOB.get(), BearRenderer::new);
        event.registerEntityRenderer(ModEntities.POPPY.get(), BearRenderer::new);
        event.registerEntityRenderer(ModEntities.FALLEN_POPPY.get(), BearRenderer::new);
        event.registerEntityRenderer(ModEntities.KILLER_BEAR.get(), BearRenderer::new);
    }

    public static class BearRenderer extends GeoEntityRenderer<BearEntity> {
        public BearRenderer(EntityRendererProvider.Context context) { super(context, new BearModel()); }
    }
    public static class BearModel extends GeoModel<BearEntity> {
        private ResourceLocation id(String path) { return new ResourceLocation("bobs_curse", path); }
        @Override public ResourceLocation getModelResource(BearEntity entity) { return id("geckolib/models/" + entity.appearance() + ".geo.json"); }
        @Override public ResourceLocation getTextureResource(BearEntity entity) { return id("textures/entity/" + entity.appearance() + ".png"); }
        @Override public ResourceLocation getAnimationResource(BearEntity entity) {
            String name = entity.appearance();
            if (name.equals("fallen_poppy")) name = "bob";
            return id("geckolib/animations/" + name + ".animation.json");
        }
    }
}
